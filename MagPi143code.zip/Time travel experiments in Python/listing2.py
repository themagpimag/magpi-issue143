import pygame, datetime, time
from pygame.locals import *
pygame.init()
calendar_surface = pygame.display.set_mode((1024, 768))

def draw_bar(fraction, row, color, color2, text):
    box = Rect((0, row * 256), (1024, 256))
    pygame.draw.rect(calendar_surface, color, box)
    box = Rect((0, row * 256), (fraction * 1024, 256))
    pygame.draw.rect(calendar_surface, color2, box)
    font_object = pygame.font.Font('freesansbold.ttf', 160)
    text_surface = font_object.render(text, True, (255, 255, 255))
    shadow_surface = font_object.render(text, True, (190, 190, 190))
    calendar_surface.blit(shadow_surface, (56, 61 + (row * 256)))
    calendar_surface.blit(text_surface, (50, 55 + (row * 256)))
    
def draw_calendar():
    days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    today = datetime.datetime.now()
    if today.year % 4 == 0:
        days_in_month[1] = 29 # leap year
    day_progress = (((today.hour * 60) + today.minute) / (60*24))
    draw_bar(day_progress, 0, (204,153,255), (178,102,255), str(today.day))
    month_progress = today.day / days_in_month[today.month - 1]
    draw_bar(month_progress, 1, (255,153,255), (255,102,255), today.strftime("%B"))
    year_progress = (sum(days_in_month[0:today.month - 1]) + today.day) / sum(days_in_month) # Split misses last value
    draw_bar(year_progress, 2, (255,153,204), (255,102,178), str(today.year))
    pygame.display.update()

while True:
    draw_calendar()
    for seconds in range(60):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
        time.sleep(1)