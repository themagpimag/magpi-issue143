import sys, time, datetime
from datetime import timedelta
import RPi.GPIO as GPIO

number_segments = [
    [1,1,1,1,1,1,0], [0,1,1,0,0,0,0],
    [1,1,0,1,1,0,1], [1,1,1,1,0,0,1],
    [0,1,1,0,0,1,1], [1,0,1,1,0,1,1],
    [1,0,1,1,1,1,1], [1,1,1,0,0,0,0],
    [1,1,1,1,1,1,1], [1,1,1,1,0,1,1]
    ]
segment_selectors = [18, 8, 36, 26, 24, 16, 38]
digit_selectors = [22, 12, 10, 40]
decimal_point = 32
GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
for pin in segment_selectors + digit_selectors + [decimal_point]:
    GPIO.setup(pin, GPIO.OUT)

def show_number(digit, number):
    switches = [1, 1, 1, 1]
    switches[digit] = 0
    GPIO.output(digit_selectors, switches)
    GPIO.output(segment_selectors, number_segments[number])
    if digit == 1:
        GPIO.output(decimal_point, 1) # on
    else:
        GPIO.output(decimal_point, 0) # off

while True:
    end_time = timedelta(hours = 17, minutes = 30)
    now_time = timedelta(hours = datetime.datetime.now().hour, minutes = datetime.datetime.now().minute)
    time_difference = "0" + str(end_time - now_time)
    if "-" in str(time_difference):
        time_difference="00:00:00"
    time_index = [-8,-7,-5,-4]
    for digit in [0, 1, 2, 3]:
        show_number(digit, int(time_difference[time_index[digit]]))
        time.sleep(0.005)