import datetime
today = datetime.datetime.now()
xmas = datetime.datetime(year=today.year, month=12, day=25)
days_to_xmas = xmas - datetime.datetime.now()
print(days_to_xmas)

